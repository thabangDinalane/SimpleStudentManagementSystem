﻿using System.Web;
using System.Web.Mvc;

namespace ASP.NetFrameworkFA1
{
    public class FilterConfig
    {
        public static void RegisterGlobalFilters(GlobalFilterCollection filters)
        {
            filters.Add(new HandleErrorAttribute());
        }
    }
}
